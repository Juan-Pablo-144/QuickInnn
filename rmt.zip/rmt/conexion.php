<?php
$host_db ="localhost";
$user_db = "root";
$pass_db = "";
$db_name = "hotel";
?>