lightbox.option({
    'resizeDuration': 300,
    'wrapAround': true
  })